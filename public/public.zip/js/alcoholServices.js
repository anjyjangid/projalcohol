AlcoholDelivery.service('productService', ['$rootScope', '$window', '$http', '$q', '$mdToast', 'alcoholCart', , function ($rootScope, $window, $http, $q, $mdToast, alcoholCart) {

	udpateProduct = function(newData){
		
	}

}]);