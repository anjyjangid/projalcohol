<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="css/owl.theme.css">
<link rel="stylesheet" type="text/css" href="css/jquery.switchButton.css">
<link rel="stylesheet" type="text/css" href="css/screen-ui.css">
<link rel="stylesheet" type="text/css" href="css/ui_responsive.css">
