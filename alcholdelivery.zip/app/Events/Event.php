<?php

namespace AlcoholDelivery\Events;

abstract class Event
{
    //
}
